import React, { useState } from 'react';
import './App.css'; // Make sure to include your updated CSS

function App() {
  const [tasks, setTasks] = useState([
    { id: "todo-0", name: "Eat", completed: true },
    { id: "todo-1", name: "Sleep", completed: false },
    { id: "todo-2", name: "Repeat", completed: false }
  ]);

  const [newTask, setNewTask] = useState('');
  const [filter, setFilter] = useState('all');
  const [editingTask, setEditingTask] = useState(null);
  const [editedTaskName, setEditedTaskName] = useState('');

  const handleInputChange = (e) => {
    setNewTask(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (newTask.trim() === '') return;
    const newTaskObj = {
      id: `todo-${tasks.length}`,
      name: newTask,
      completed: false
    };
    setTasks([...tasks, newTaskObj]);
    setNewTask('');
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const handleEditChange = (e) => {
    setEditedTaskName(e.target.value);
  };

  const startEditing = (task) => {
    setEditingTask(task.id);
    setEditedTaskName(task.name);
  };

  const saveEdit = (id) => {
    setTasks(tasks.map(task =>
      task.id === id ? { ...task, name: editedTaskName } : task
    ));
    setEditingTask(null);
  };

  const handleFilterChange = (filter) => {
    setFilter(filter);
  };

  const getFilteredTasks = () => {
    switch (filter) {
      case 'active':
        return tasks.filter(task => !task.completed);
      case 'completed':
        return tasks.filter(task => task.completed);
      default:
        return tasks;
    }
  };

  const filteredTasks = getFilteredTasks();

  return (
    <div className="todo-app">
      <h1 className="app-title">My Tasks</h1>
      <form className="task-form" onSubmit={handleSubmit}>
        <input
          type="text"
          className="task-input"
          placeholder="What are you planning?"
          value={newTask}
          onChange={handleInputChange}
        />
        <button type="submit" className="btn btn-primary">
          Add Task
        </button>
      </form>
      <div className="filter-buttons">
        {['all', 'active', 'completed'].map(status => (
          <button
            key={status}
            className={`btn filter-btn ${filter === status ? 'active' : ''}`}
            onClick={() => handleFilterChange(status)}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>
      <h2 className="task-count">{filteredTasks.length} tasks remaining</h2>
      <ul className="task-list">
        {filteredTasks.map(task => (
          <li key={task.id} className="task-item">
            <div className="task-content">
              <input
                type="checkbox"
                checked={task.completed}
                onChange={() => {
                  setTasks(tasks.map(t =>
                    t.id === task.id ? { ...t, completed: !t.completed } : t
                  ));
                }}
              />
              {editingTask === task.id ? (
                <input
                  type="text"
                  value={editedTaskName}
                  onChange={handleEditChange}
                />
              ) : (
                <span className={`task-text ${task.completed ? 'completed' : ''}`}>
                  {task.name}
                </span>
              )}
            </div>
            <div className="task-actions">
              {editingTask === task.id ? (
                <button className="btn btn-secondary" onClick={() => saveEdit(task.id)}>Save</button>
              ) : (
                <>
                  <button className="btn btn-edit" onClick={() => startEditing(task)}>Edit</button>
                  <button className="btn btn-danger" onClick={() => deleteTask(task.id)}>Delete</button>
                </>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
