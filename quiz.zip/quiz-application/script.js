document.addEventListener('DOMContentLoaded', () => {
    const questions = [
        {
            question: "What is the capital of pakistan?",
            choices: ["Lahore", "islamabad", "karachi", "quetta"],
            answer: "Paris"
        },
        {
            question: "What is 2 + 2?",
            choices: ["3", "4", "5", "6"],
            answer: "4"
        },
        {
            question: "Which planet is known as the Red Planet?",
            choices: ["Earth", "Mars", "Jupiter", "Saturn"],
            answer: "Mars"
        },
        {
            question: "What is the smallest planet in our solar system?",
            choices: ["Mercury", "Mars", "Venus", "Earth"],
            answer: "Mercury"
        },
        {
            question: "What is the largest ocean on Earth?",
            choices: ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"],
            answer: "Pacific Ocean"
        }
    ];

    let currentQuestionIndex = 0;
    let score = 0;

    const questionElement = document.getElementById('question');
    const choicesElement = document.getElementById('choices');
    const resultElement = document.getElementById('result');
    const scoreElement = document.getElementById('score');
    const restartButton = document.getElementById('restart');
    const submitButton = document.getElementById('submit');

    function showQuestion() {
        const question = questions[currentQuestionIndex];
        questionElement.textContent = question.question;
        choicesElement.innerHTML = '';
        question.choices.forEach(choice => {
            const li = document.createElement('li');
            li.textContent = choice;
            li.addEventListener('click', () => {
                if (choice === question.answer) {
                    score++;
                }
                currentQuestionIndex++;
                if (currentQuestionIndex < questions.length) {
                    showQuestion();
                } else {
                    showResult();
                }
            });
            choicesElement.appendChild(li);
        });
    }

    function showResult() {
        questionElement.style.display = 'none';
        choicesElement.style.display = 'none';
        submitButton.style.display = 'none';
        resultElement.classList.remove('hidden');
        scoreElement.textContent = `Your score is ${score} out of ${questions.length}`;
    }

    submitButton.addEventListener('click', () => {
        currentQuestionIndex++;
        if (currentQuestionIndex < questions.length) {
            showQuestion();
        } else {
            showResult();
        }
    });

    restartButton.addEventListener('click', () => {
        currentQuestionIndex = 0;
        score = 0;
        resultElement.classList.add('hidden');
        questionElement.style.display = 'block';
        choicesElement.style.display = 'block';
        submitButton.style.display = 'block';
        showQuestion();
    });

    showQuestion();
});
