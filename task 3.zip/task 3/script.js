const books = [];
const history = [];

// Add a new book to the list
function addBook() {
    const title = document.getElementById('bookTitle').value;
    const author = document.getElementById('bookAuthor').value;
    const category = document.getElementById('bookCategory').value;

    if (title && author && category) {
        const book = { title, author, category };
        books.push(book);
        updateBooksList();
        document.getElementById('bookForm').reset();
        logHistory(`Added book: ${title} by ${author}`);
    }
}

// Update the book list display
function updateBooksList() {
    const booksList = document.getElementById('booksList');
    booksList.innerHTML = '';
    books.forEach(book => {
        const div = document.createElement('div');
        div.classList.add('book-item');
        div.innerText = `${book.title} by ${book.author} - Category: ${book.category}`;
        booksList.appendChild(div);
    });
}

// Search books by title or author
function searchBooks() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const searchResults = document.getElementById('searchResults');
    searchResults.innerHTML = '';
    const results = books.filter(book => 
        book.title.toLowerCase().includes(searchInput) || 
        book.author.toLowerCase().includes(searchInput)
    );
    results.forEach(book => {
        const div = document.createElement('div');
        div.classList.add('book-item');
        div.innerText = `${book.title} by ${book.author} - Category: ${book.category}`;
        searchResults.appendChild(div);
    });
}

// Log borrowing history
function logHistory(action) {
    history.push({ date: new Date().toLocaleString(), action });
    updateHistoryList();
}

// Update the history display
function updateHistoryList() {
    const historyList = document.getElementById('historyList');
    historyList.innerHTML = '';
    history.forEach(entry => {
        const li = document.createElement('li');
        li.innerText = `${entry.date}: ${entry.action}`;
        historyList.appendChild(li);
    });
}
